import random
import os

def clear_screen():
    """Clear the console screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_rules():
    """Display the game rules"""
    print("\n" + "="*50)
    print("          ROCK PAPER SCISSORS SHOOT!")
    print("="*50)
    print("Rules:")
    print("• Rock beats Scissors")
    print("• Scissors beats Paper") 
    print("• Paper beats Rock")
    print("• Choose wisely! First to 3 points wins!")
    print("="*50 + "\n")

def get_player_choice():
    """Get and validate player's choice"""
    while True:
        print("\nYour choices:")
        print("1. Rock")
        print("2. Paper") 
        print("3. Scissors")
        print("4. Quit")
        
        choice = input("\nEnter your choice (1-4): ").strip().lower()
        
        if choice == '1' or choice == 'rock' or choice == 'r':
            return 'rock'
        elif choice == '2' or choice == 'paper' or choice == 'p':
            return 'paper'
        elif choice == '3' or choice == 'scissors' or choice == 's':
            return 'scissors'
        elif choice == '4' or choice == 'quit' or choice == 'q':
            return 'quit'
        else:
            print("❌ Invalid choice! Please enter 1, 2, 3, or 4.")

def get_computer_choice():
    """Get computer's random choice"""
    choices = ['rock', 'paper', 'scissors']
    return random.choice(choices)

def determine_winner(player, computer):
    """Determine winner of the round"""
    if player == computer:
        return 'tie'
    elif (player == 'rock' and computer == 'scissors') or \
         (player == 'scissors' and computer == 'paper') or \
         (player == 'paper' and computer == 'rock'):
        return 'player'
    else:
        return 'computer'

def display_round_result(player, computer, result):
    """Display the result of the round"""
    print(f"\n🎮 SHOOT!")
    print(f"Player: {player.upper()} 🆚 Computer: {computer.upper()}")
    print("-" * 40)
    
    if result == 'tie':
        print("🤝 It's a TIE!")
    elif result == 'player':
        print("🎉 PLAYER WINS this round!")
    else:
        print("🤖 COMPUTER WINS this round!")
    
    print("-" * 40)

def main():
    """Main game loop"""
    clear_screen()
    display_rules()
    
    player_score = 0
    computer_score = 0
    rounds_played = 0
    max_rounds = 5  # Best of 5
    
    while True:
        print(f"\nScore: Player {player_score} - {computer_score} Computer")
        print(f"Round {rounds_played + 1}/{max_rounds}")
        
        player_choice = get_player_choice()
        
        if player_choice == 'quit':
            print("\n👋 Thanks for playing! Goodbye!")
            break
        
        computer_choice = get_computer_choice()
        result = determine_winner(player_choice, computer_choice)
        display_round_result(player_choice, computer_choice, result)
        
        # Update scores
        if result == 'player':
            player_score += 1
        elif result == 'computer':
            computer_score += 1
        
        rounds_played += 1
        
        # Check for game end
        if rounds_played >= max_rounds or player_score >= 3 or computer_score >= 3:
            clear_screen()
            print("\n🏆 FINAL RESULTS 🏆")
            print(f"Player Score: {player_score}")
            print(f"Computer Score: {computer_score}")
            print("-" * 40)
            
            if player_score > computer_score:
                print("🎊 CONGRATULATIONS! YOU WIN! 🎊")
            elif computer_score > player_score:
                print("😢 Computer wins! Better luck next time!")
            else:
                print("🤝 It's a DRAW!")
            
            play_again = input("\nPlay again? (y/n): ").strip().lower()
            if play_again in ['y', 'yes']:
                # Reset game
                player_score = 0
                computer_score = 0
                rounds_played = 0
                clear_screen()
                display_rules()
            else:
                print("\n👋 Thanks for playing Rock Paper Scissors Shoot!")
                break

if __name__ == "__main__":
    main()